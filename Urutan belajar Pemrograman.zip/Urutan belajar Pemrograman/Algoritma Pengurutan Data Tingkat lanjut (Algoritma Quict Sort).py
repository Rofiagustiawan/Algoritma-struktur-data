# ----------------------------------
# QUICK SORT SEDERHANA
# ----------------------------------

def quick_sort(data):
    print("Memproses:", data)

    # Jika panjang data hanya 1 atau kosong → sudah terurut
    if len(data) <= 1:
        return data

    # Menggunakan elemen pertama sebagai pivot
    pivot = data[0]
    left = []
    right = []

    # Memisahkan elemen menjadi dua sisi
    for x in data[1:]:
        if x < pivot:
            left.append(x)
        else:
            right.append(x)

    print(f"Pivot: {pivot} | Left: {left} | Right: {right}")

    # Rekursif quick sort kiri dan kanan
    left_sorted = quick_sort(left)
    right_sorted = quick_sort(right)

    # Menggabungkan hasil
    return left_sorted + [pivot] + right_sorted


# ---------------------------
# CONTOH PENGGUNAAN
# ---------------------------
angka = [29, 10, 14, 37, 14]

print("\nHASIL AKHIR:", quick_sort(angka))


print("\n=== SETELAH DI MODIFIKASI ===\n")

import tkinter as tk
from tkinter import messagebox

# ----------------------------------
# FUNGSI QUICK SORT DENGAN OUTPUT TKINTER
# ----------------------------------

def quick_sort_gui(data, output_box, depth=0):
    output_box.insert(tk.END, f"{'   '*depth}Memproses: {data}\n")
    output_box.see(tk.END)

    if len(data) <= 1:
        return data

    pivot = data[0]
    left = []
    right = []

    for x in data[1:]:
        if x < pivot:
            left.append(x)
        else:
            right.append(x)

    output_box.insert(tk.END, f"{'   '*depth}Pivot: {pivot} | Left: {left} | Right: {right}\n")
    output_box.see(tk.END)

    left_sorted = quick_sort_gui(left, output_box, depth+1)
    right_sorted = quick_sort_gui(right, output_box, depth+1)

    merged = left_sorted + [pivot] + right_sorted
    return merged

# ----------------------------------
# GUI TKINTER
# ----------------------------------

def mulai_sort():
    angka_str = entry.get()
    try:
        angka = [int(x) for x in angka_str.replace(" ", "").split(",")]
    except:
        messagebox.showerror("Error", "Format input salah!\nContoh: 29,10,14,37,14")
        return

    output_box.delete(1.0, tk.END)

    hasil = quick_sort_gui(angka, output_box)
    output_box.insert(tk.END, f"\nHASIL AKHIR: {hasil}\n")
    output_box.see(tk.END)

def refresh():
    entry.delete(0, tk.END)
    output_box.delete(1.0, tk.END)

def keluar():
    root.destroy()

# ----------------------------------
# SETUP TKINTER
# ----------------------------------

root = tk.Tk()
root.title("Quick Sort Visualizer")
root.geometry("600x500")
root.resizable(False, False)

title = tk.Label(root, text="QUICK SORT SEDERHANA", font=("Arial", 16, "bold"))
title.pack(pady=10)

frame = tk.Frame(root)
frame.pack()

label = tk.Label(frame, text="Masukkan angka (pisahkan dengan koma):")
label.pack()

entry = tk.Entry(frame, width=40, font=("Arial", 12))
entry.pack()
entry.insert(0, "29,10,14,37,14")
entry.bind("<Return>", lambda event: mulai_sort())   # Enter untuk mulai

btn_frame = tk.Frame(root)
btn_frame.pack(pady=10)

tk.Button(btn_frame, text="Mulai Sort", width=12, command=mulai_sort).grid(row=0, column=0, padx=5)
tk.Button(btn_frame, text="Refresh", width=12, command=refresh).grid(row=0, column=1, padx=5)
tk.Button(btn_frame, text="Keluar", width=12, command=keluar).grid(row=0, column=2, padx=5)

output_box = tk.Text(root, width=70, height=20, font=("Consolas", 10))
output_box.pack(pady=10)

root.mainloop()
