# ----------------------------------
# SELECTION SORT SEDERHANA
# ----------------------------------

def selection_sort(data):
    n = len(data)
    print("Data sebelum diurutkan:", data)

    # Proses selection sort
    for i in range(n):
        min_index = i  # anggap elemen pertama sebagai yang terkecil

        # mencari nilai terkecil dari sisa elemen
        for j in range(i + 1, n):
            if data[j] < data[min_index]:
                min_index = j

        # menukar elemen terkecil dengan elemen posisi i
        data[i], data[min_index] = data[min_index], data[i]

        print(f"Iterasi ke-{i+1}: {data}")

    print("Data setelah diurutkan:", data)


# Contoh penggunaan
angka = [64, 25, 12, 22, 11]

selection_sort(angka)

print("\n=== SETELAH DI MODIFIKASI ===\n")


# ----------------------------------------
# SELECTION SORT (DENGAN PROSES LENGKAP)
# ----------------------------------------

def selection_sort(data):
    n = len(data)
    print("Data sebelum diurutkan:", data)
    print("-" * 50)

    # Proses selection sort
    for i in range(n):
        min_index = i
        print(f"Iterasi ke-{i+1}:")
        print(f"  - Mulai dari indeks {i} (nilai = {data[i]})")

        # Mencari nilai terkecil dalam sisa array
        for j in range(i + 1, n):
            print(f"    > Bandingkan {data[j]} dengan {data[min_index]}")
            if data[j] < data[min_index]:
                min_index = j
                print(f"      >> Nilai minimum baru ditemukan di indeks {min_index} ({data[min_index]})")

        # Menampilkan proses sebelum pertukaran
        print(f"  - Minimum ditemukan pada indeks {min_index} ({data[min_index]})")
        print(f"  - Sebelum tukar : {data}")

        # Menukar elemen
        data[i], data[min_index] = data[min_index], data[i]

        # Menampilkan hasil setelah pertukaran
        print(f"  - Setelah tukar : {data}")
        print("-" * 50)

    print("Data setelah diurutkan:", data)


# Contoh penggunaan
angka = [64, 25, 12, 22, 11]

selection_sort(angka)
