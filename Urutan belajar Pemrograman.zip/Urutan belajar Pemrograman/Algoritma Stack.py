# ---------------------------------------
# CONTOH PERANCANGAN STACK SEDERHANA
# ---------------------------------------

# Membuat class Stack
class Stack:
    def __init__(self):
        self.data = []

    # Push: menambahkan elemen
    def push(self, item):
        self.data.append(item)
        print(f"Push: {item} ditambahkan ke stack.")

    # Pop: menghapus elemen terakhir
    def pop(self):
        if self.is_empty():
            print("Stack kosong! Tidak bisa pop.")
            return None
        removed = self.data.pop()
        print(f"Pop: {removed} dihapus dari stack.")
        return removed

    # Peek: melihat elemen teratas
    def peek(self):
        if self.is_empty():
            return None
        return self.data[-1]

    # Cek apakah stack kosong
    def is_empty(self):
        return len(self.data) == 0

    # Menampilkan isi stack
    def tampilkan(self):
        print("Isi stack:", self.data)


# ---------------------------------------
# PENGGUNAAN STACK
# ---------------------------------------

stack = Stack()

stack.push("Apel")
stack.push("Mangga")
stack.push("Jeruk")

stack.tampilkan()

print("\nElemen teratas (peek):", stack.peek())

stack.pop()
stack.tampilkan()

stack.pop()
stack.pop()

print("\nCek apakah stack kosong:", stack.is_empty())

print("\n=== SETELAH DI MODIFIKASI ===")

# ---------------------------
# PERANCANGAN STACK SEDERHANA 
# ---------------------------

class Stack:
    def __init__(self):
        self.data = []

    # Push: menambahkan elemen ke atas stack
    def push(self, item):
        self.data.append(item)
        print(f"\n[PUSH] '{item}' ditambahkan ke stack.")

    # Pop: menghapus elemen paling atas
    def pop(self):
        if self.is_empty():
            print("[POP] Gagal! Stack kosong.")
            return None
        removed = self.data.pop()
        print(f"[POP] '{removed}' dihapus dari stack.")
        return removed

    # Peek: melihat elemen paling atas
    def peek(self):
        if self.is_empty():
            print("[PEEK] Stack kosong.")
            return None
        print(f"[PEEK] Elemen teratas adalah: '{self.data[-1]}'")
        return self.data[-1]

    # Mengecek apakah stack kosong
    def is_empty(self):
        return len(self.data) == 0

    # Menampilkan isi stack dari bawah ke atas
    def tampilkan(self):
        print("\n=== ISI STACK ===")
        if self.is_empty():
            print("(kosong)")
        else:
            for i, item in enumerate(self.data):
                if i == len(self.data) - 1:
                    print(f"{item}  <-- TOP")
                else:
                    print(item)
        print("=================\n")


# ---------------------------------------
# PENGGUNAAN STACK
# ---------------------------------------

stack = Stack()

stack.push("Apel")
stack.push("Mangga")
stack.push("Jeruk")

stack.tampilkan()

stack.peek()

stack.pop()
stack.tampilkan()

stack.pop()
stack.pop()

print("Apakah stack kosong?", stack.is_empty())
