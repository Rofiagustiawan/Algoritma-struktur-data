# -------------------------------
# PERANCANGAN ARRAY SEDERHANA
# -------------------------------

# Membuat array (list) buah
buah = ["Apel", "Mangga", "Jeruk", "Pisang"]

# Menampilkan array buah
print("Daftar buah awal:", buah)

# Mengakses elemen array
print("Buah pertama:", buah[0])
print("Buah terakhir:", buah[-1])

# Menambah elemen baru ke dalam array
buah.append("Semangka")
print("Setelah menambah buah baru:", buah)

# Mengubah nilai salah satu elemen
buah[1] = "Anggur"
print("Setelah mengubah Mangga menjadi Anggur:", buah)

# Menghapus elemen dari array
buah.remove("Jeruk")
print("Setelah menghapus Jeruk:", buah)

# Menampilkan jumlah elemen
print("Jumlah buah dalam array:", len(buah))

# Menampilkan semua buah satu per satu
print("\nDaftar buah satu per satu:")
for item in buah:
    print("-", item)

print("\n=== SETELAH DI MODIFIKASI ===")

# -------------------------------------
# PERANCANGAN ARRAY SEDERHANA (MODIFIKASI)
# -------------------------------------

# Membuat array (list) buah
buah = ["Apel", "Mangga", "Jeruk", "Pisang"]

print("\n=== DATA BUAH AWAL ===")
print(buah)

# Mengakses elemen array
print("\nBuah pertama:", buah[0])
print("Buah terakhir:", buah[-1])

# Menambah elemen baru berdasarkan input
buah_baru = input("\nMasukkan buah baru yang ingin ditambahkan: ")
buah.append(buah_baru)
print("Setelah menambah buah baru:", buah)

# Mengubah elemen tertentu
buah[1] = "Anggur"
print("\nMengubah 'Mangga' menjadi 'Anggur':")
print(buah)

# Menghapus buah berdasarkan nama (jika ada)
hapus = input("\nMasukkan nama buah yang ingin dihapus: ")

if hapus in buah:
    buah.remove(hapus)
    print("Setelah menghapus", hapus + ":", buah)
else:
    print(hapus, "tidak ditemukan dalam array!")

# Menghapus buah berdasarkan index
try:
    idx = int(input("\nMasukkan index buah yang ingin dihapus (0 - {}): ".format(len(buah)-1)))
    buah.pop(idx)
    print("Setelah menghapus berdasarkan index:", buah)
except:
    print("Index tidak valid!")

# Menampilkan jumlah elemen
print("\nJumlah buah saat ini:", len(buah))

# Menampilkan seluruh data buah
print("\n=== DAFTAR BUAH TERBARU ===")
for item in buah:
    print("-", item)

# Fitur tambahan: mencari buah
cari = input("\nCari buah: ")
if cari in buah:
    print(cari, "ADA dalam daftar buah!")
else:
    print(cari, "TIDAK ditemukan.")
