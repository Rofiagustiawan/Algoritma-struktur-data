class UnionBuah:
    def __init__(self):
        self.nama = None
        self.harga = None
        self.stok = None

# Membuat objek union
data = UnionBuah()

# Isi union dengan nama buah
data.nama = "Jeruk"
print("Nama aktif :", data.nama)

# Alihkan union menjadi harga
data.harga = 20000
data.nama = None  # menonaktifkan field sebelumnya
print("Harga aktif:", data.harga)

# Alihkan union menjadi stok
data.stok = 40
data.harga = None
print("Stok aktif :", data.stok)

print("\n=== SETELAH DI MODIFIKASI ===")

class UnionBuah:
    def __init__(self):
        self.nama = None
        self.harga = None
        self.stok = None

    # Fungsi untuk mengatur union (hanya satu aktif)
    def set_data(self, tipe, nilai):
        # Reset semua field
        self.nama = None
        self.harga = None
        self.stok = None

        # Pilih field yang aktif
        if tipe == "nama":
            self.nama = nilai
        elif tipe == "harga":
            self.harga = nilai
        elif tipe == "stok":
            self.stok = nilai
        else:
            print("Tipe tidak dikenal.")

    # Fungsi untuk menampilkan data aktif
    def tampilkan(self):
        if self.nama is not None:
            print("\nData aktif: Nama Buah  =", self.nama)
        elif self.harga is not None:
            print("Data aktif: Harga Buah =", self.harga)
        elif self.stok is not None:
            print("Data aktif: Stok Buah  =", self.stok)
        else:
            print("Tidak ada data aktif.")


# Penggunaan union
data = UnionBuah()

# Isi union dengan nama buah
data.set_data("nama", "Jeruk")
data.tampilkan()

# Alihkan union menjadi harga
data.set_data("harga", 20000)
data.tampilkan()

# Alihkan union menjadi stok
data.set_data("stok", 40)
data.tampilkan()
