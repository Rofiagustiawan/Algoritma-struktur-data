# -------------------------------
# TIPE DATA CHARACTER (STRING 1 KARAKTER)
# -------------------------------

# Menyimpan karakter
huruf = 'A'
simbol = '#'
angka_karakter = '5'  # meskipun angka, ini tetap karakter (string 1 huruf)

# Menampilkan karakter
print("Karakter huruf:", huruf)
print("Karakter simbol:", simbol)
print("Karakter angka:", angka_karakter)

# Mengecek tipe data
print("Tipe huruf:", type(huruf))
print("Tipe simbol:", type(simbol))
print("Tipe angka_karakter:", type(angka_karakter))

print("\n=== SETELAH DI MODIFIKASI ===\n")

# -------------------------------
# TIPE DATA CHARACTER (STRING 1 KARAKTER) - MODIFIKASI
# -------------------------------

# Meminta input karakter dari pengguna
ch = input("Masukkan satu karakter: ")[0]  # Ambil karakter pertama jika lebih dari 1

print("\nKarakter yang dimasukkan:", ch)
print("Tipe data:", type(ch))

# Mengecek jenis karakter
if ch.isalpha():
    if ch.isupper():
        print("Ini adalah huruf besar.")
    else:
        print("Ini adalah huruf kecil.")
elif ch.isdigit():
    print("Ini adalah angka (karakter).")
else:
    print("Ini adalah simbol atau karakter khusus.")
