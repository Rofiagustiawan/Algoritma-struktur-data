# ----------------------------------
# SHELL SORT SEDERHANA
# ----------------------------------

def shell_sort(data):
    print("Data sebelum diurutkan:", data)

    n = len(data)
    gap = n // 2   # Jarak awal (gap)

    # Selama gap masih > 0
    while gap > 0:
        print(f"\n--- Gap saat ini: {gap} ---")

        # Lakukan Insertion Sort versi gap
        for i in range(gap, n):
            temp = data[i]
            j = i

            print(f"Memasukkan {temp} pada posisi yang tepat...")

            # Geser elemen yang lebih besar ke kanan dengan jarak 'gap'
            while j >= gap and data[j - gap] > temp:
                print(f"  Geser {data[j - gap]} dari index {j-gap} ke index {j}")
                data[j] = data[j - gap]
                j -= gap

            # Tempatkan nilai pada posisi yang tepat
            data[j] = temp
            print("  Data saat ini:", data)

        # Kurangi gap
        gap //= 2

    print("\nData setelah diurutkan:", data)


# Contoh penggunaan
angka = [12, 34, 54, 2, 3]

shell_sort(angka)

print("\n=== SETELAH DI MODIFIKASI ===\n")

import tkinter as tk
from tkinter import messagebox


def shell_sort_gui(data, output_box):
    output_box.delete("1.0", tk.END)
    output_box.insert(tk.END, f"Data sebelum diurutkan: {data}\n")

    n = len(data)
    gap = n // 2   # Gap awal

    while gap > 0:
        output_box.insert(tk.END, f"\n--- Gap saat ini: {gap} ---\n")

        for i in range(gap, n):
            temp = data[i]
            j = i
            output_box.insert(tk.END, f"Memasukkan {temp}...\n")

            # Geser elemen
            while j >= gap and data[j - gap] > temp:
                output_box.insert(
                    tk.END, 
                    f"  Geser {data[j - gap]} dari index {j-gap} ke index {j}\n"
                )
                data[j] = data[j - gap]
                j -= gap

            data[j] = temp
            output_box.insert(tk.END, f"  Data saat ini: {data}\n")

        gap //= 2

    output_box.insert(tk.END, f"\nData setelah diurutkan: {data}\n")


# ----------------------------------
# GUI TKINTER
# ----------------------------------

def mulai_sort():
    try:
        # Ambil input dan ubah ke list angka
        data = list(map(int, entry.get().split(",")))
        shell_sort_gui(data, output_box)
    except:
        messagebox.showerror("Error", "Format input salah!\nGunakan format: 12,34,54,2,3")

def reset_data():
    entry.delete(0, tk.END)
    output_box.delete("1.0", tk.END)

def keluar():
    root.destroy()


# Tkinter Window
root = tk.Tk()
root.title("Shell Sort GUI - Tkinter")
root.geometry("600x500")

# Input Label & Entry
tk.Label(root, text="Masukkan angka (dipisah koma):").pack()
entry = tk.Entry(root, width=40)
entry.pack(pady=5)
entry.insert(0, "12,34,54,2,3")

# Tombol
frame_btn = tk.Frame(root)
frame_btn.pack(pady=10)

tk.Button(frame_btn, text="Mulai", width=10, command=mulai_sort).grid(row=0, column=0, padx=5)
tk.Button(frame_btn, text="Reset", width=10, command=reset_data).grid(row=0, column=1, padx=5)
tk.Button(frame_btn, text="Keluar", width=10, command=keluar).grid(row=0, column=2, padx=5)

# Output Box
output_box = tk.Text(root, height=20, width=70)
output_box.pack(pady=10)

root.mainloop()

