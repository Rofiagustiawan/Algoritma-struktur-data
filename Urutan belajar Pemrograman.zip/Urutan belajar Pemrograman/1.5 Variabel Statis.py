class Buah:
    jumlah_buah = 0   # variabel statis (milik class)

    def __init__(self, nama):
        self.nama = nama
        Buah.jumlah_buah += 1


# Membuat objek
apel = Buah("Apel")
jeruk = Buah("Jeruk")

print("Nama buah 1:", apel.nama)
print("Nama buah 2:", jeruk.nama)

# Mengakses variabel statis
print("Total buah:", Buah.jumlah_buah)

print("\n=== SETELAH DI MODIFIKASI ===")

class Buah:
    jumlah_buah = 0       # variabel statis
    daftar_buah = []      # variabel statis tambahan untuk menyimpan semua buah

    def __init__(self, nama, harga, stok):
        self.nama = nama
        self.harga = harga
        self.stok = stok

        # Setiap membuat objek baru → jumlah bertambah
        Buah.jumlah_buah += 1
        Buah.daftar_buah.append(self)

    def info(self):
        print(f"Nama: {self.nama}, Harga: {self.harga}, Stok: {self.stok}")


# Membuat beberapa objek
apel = Buah("Apel", 15000, 30)
jeruk = Buah("Jeruk", 18000, 25)

# Menampilkan data tiap buah
print("\n=== DATA SETIAP BUAH ===")
apel.info()
jeruk.info()

# Mengakses variabel statis
print("\nTotal jenis buah :", Buah.jumlah_buah)

print("\n=== MENAMPILKAN SEMUA BUAH (DARI VARIABEL STATIS) ===")
for b in Buah.daftar_buah:
    b.info()
