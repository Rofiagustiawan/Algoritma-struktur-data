# ----------------------------------------
# PERANCANGAN UNIONS SEDERHANA DI PYTHON
# ----------------------------------------

class UnionBuah:
    def __init__(self):
        self.data = None    # union hanya simpan satu data dalam satu waktu
        self.tipe = None    # untuk menyimpan tipe data aktif (nama/harga/stok)

    def set_nama(self, nama):
        self.data = nama
        self.tipe = "Nama"

    def set_harga(self, harga):
        self.data = harga
        self.tipe = "Harga"

    def set_stok(self, stok):
        self.data = stok
        self.tipe = "Stok"

    def tampil(self):
        print(f"{self.tipe} buah yang aktif:", self.data)


# Membuat objek union
u = UnionBuah()

# Mengisi union dengan nama buah
u.set_nama("Apel")
u.tampil()

# Mengganti isi union menjadi harga
u.set_harga(15000)
u.tampil()

# Mengganti isi union menjadi stok
u.set_stok(40)
u.tampil()

print("\n=== SETELAH DI MODIFIKASI ===")

# ----------------------------------------
# PERANCANGAN UNIONS SEDERHANA DI PYTHON
# ----------------------------------------

class UnionBuah:
    def __init__(self):
        self.data = None
        self.tipe = None

    # Mengatur data union (otomatis mengganti data lama)
    def set_nama(self, nama):
        self.data = nama
        self.tipe = "Nama Buah"

    def set_harga(self, harga):
        self.data = harga
        self.tipe = "Harga Buah"

    def set_stok(self, stok):
        self.data = stok
        self.tipe = "Stok Buah"

    # Menampilkan data aktif
    def tampil(self):
        print(f"Data aktif ({self.tipe}): {self.data}")

    # Cek apakah data masih aktif
    def status(self):
        print(f"Status union → Tipe aktif: {self.tipe}, Isi: {self.data}")


# Membuat objek union
u = UnionBuah()

print("\n=== UNION DATA BUAH ===\n")

# Mengisi union dengan nama buah
u.set_nama("Mangga")
u.tampil()
u.status()

print("\n--- Mengubah isi union menjadi harga ---")
u.set_harga(20000)
u.tampil()
u.status()

print("\n--- Mengubah isi union menjadi stok ---")
u.set_stok(55)
u.tampil()
u.status()
