# ----------------------------------
# MERGE SORT SEDERHANA
# ----------------------------------

def merge_sort(data):
    print("Memproses:", data)

    # Jika panjang data hanya 1, langsung return (sudah terurut)
    if len(data) <= 1:
        return data

    # Membagi data menjadi 2 bagian
    mid = len(data) // 2
    left = data[:mid]
    right = data[mid:]

    print(f"Membagi menjadi {left} dan {right}")

    # Rekursif: urutkan kedua bagian
    left_sorted = merge_sort(left)
    right_sorted = merge_sort(right)

    # Gabungkan kedua bagian yang sudah terurut
    merged = merge(left_sorted, right_sorted)

    print(f"Menggabungkan {left_sorted} + {right_sorted} → {merged}")

    return merged


def merge(left, right):
    result = []
    i = j = 0

    # Bandingkan elemen kiri dan kanan
    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    # Tambahkan sisa elemen
    result.extend(left[i:])
    result.extend(right[j:])

    return result


# Contoh penggunaan
angka = [38, 27, 43, 3, 9, 82, 10]
print("\nHasil akhir:", merge_sort(angka))

print("\n=== SETELAH DI MODIFIKASI ===\n")

import tkinter as tk
from tkinter import messagebox

# ----------------------------------
# FUNGSI MERGE SORT DENGAN TAMBAHAN OUTPUT KE TKINTER
# ----------------------------------

def merge_sort(data, output_box, depth=0):
    output_box.insert(tk.END, f"{'   ' * depth}Memproses: {data}\n")
    output_box.see(tk.END)

    if len(data) <= 1:
        return data

    mid = len(data) // 2
    left = data[:mid]
    right = data[mid:]

    output_box.insert(tk.END, f"{'   ' * depth}Membagi menjadi: {left} dan {right}\n")
    output_box.see(tk.END)

    left_sorted = merge_sort(left, output_box, depth + 1)
    right_sorted = merge_sort(right, output_box, depth + 1)

    merged = merge(left_sorted, right_sorted)

    output_box.insert(
        tk.END,
        f"{'   ' * depth}Menggabungkan {left_sorted} + {right_sorted} → {merged}\n"
    )
    output_box.see(tk.END)

    return merged


def merge(left, right):
    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])
    return result


# ----------------------------------
# GUI TKINTER
# ----------------------------------

def mulai_sort():
    angka_str = entry.get()

    try:
        # menerima input tanpa harus pakai spasi (contoh: 5,3,8,1)
        angka = [int(x) for x in angka_str.replace(" ", "").split(",")]
    except:
        messagebox.showerror("Error", "Format input salah!\nContoh: 5,3,8,1")
        return

    output_box.delete(1.0, tk.END)

    hasil = merge_sort(angka, output_box)

    output_box.insert(tk.END, f"\nHASIL AKHIR: {hasil}\n")


def refresh():
    entry.delete(0, tk.END)
    output_box.delete(1.0, tk.END)


# ----------------------------------
# SETUP TKINTER
# ----------------------------------

root = tk.Tk()
root.title("Merge Sort Visualizer")
root.geometry("600x500")
root.resizable(False, False)

title = tk.Label(root, text="MERGE SORT SEDERHANA", font=("Arial", 16, "bold"))
title.pack(pady=10)

frame = tk.Frame(root)
frame.pack()

label = tk.Label(frame, text="Masukkan angka (pisahkan dengan koma):")
label.pack()

entry = tk.Entry(frame, width=40, font=("Arial", 12))
entry.pack()
entry.bind("<Return>", lambda event: mulai_sort())   # Tekan Enter untuk mulai

btn_frame = tk.Frame(root)
btn_frame.pack(pady=10)

btn_start = tk.Button(btn_frame, text="Mulai Sort", width=12, command=mulai_sort)
btn_start.grid(row=0, column=0, padx=5)

btn_refresh = tk.Button(btn_frame, text="Refresh", width=12, command=refresh)
btn_refresh.grid(row=0, column=1, padx=5)

output_box = tk.Text(root, width=70, height=20, font=("Consolas", 10))
output_box.pack(pady=10)

root.mainloop()
