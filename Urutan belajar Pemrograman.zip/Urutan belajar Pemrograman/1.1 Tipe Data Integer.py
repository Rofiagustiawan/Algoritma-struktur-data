a = 10
b = 5

print("Penjumlahan :", a + b)
print("Pengurangan :", a - b)
print("Perkalian   :", a * b)
print("Pembagian   :", a / b)    # hasilnya float

print("\n=== SETELAH DI MODIFIKASI===")

a = 10
b = 5

print("\nAngka pertama (a):", a)
print("Angka kedua   (b):", b)

print("\n--- HASIL OPERASI ---")
print("1. Penjumlahan (a + b)        :", a + b)
print("2. Pengurangan (a - b)        :", a - b)
print("3. Perkalian (a * b)          :", a * b)
print("4. Pembagian (a / b)          :", a / b)

# Tambahan operasi lainnya
print("\n--- OPERASI TAMBAHAN ---")
print("5. Pembagian bulat (a // b)   :", a // b)
print("6. Sisa bagi / Modulus (a % b):", a % b)
print("7. Pangkat (a ** b)           :", a ** b)
