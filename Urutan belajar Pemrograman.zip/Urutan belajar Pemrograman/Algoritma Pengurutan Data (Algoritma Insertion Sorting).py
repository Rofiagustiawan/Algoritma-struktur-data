# ----------------------------------
# INSERTION SORT SEDERHANA
# ----------------------------------

def insertion_sort(data):
    print("Data sebelum diurutkan:", data)

    # Mulai dari indeks 1 karena indeks 0 dianggap sudah terurut
    for i in range(1, len(data)):
        key = data[i]          # elemen yang akan disisipkan
        j = i - 1

        print(f"\nIterasi ke-{i}: Memasukkan {key}")

        # Geser elemen yang lebih besar ke kanan
        while j >= 0 and data[j] > key:
            print(f"  Geser {data[j]} ke posisi {j+1}")
            data[j + 1] = data[j]
            j -= 1

        # Menempatkan key pada posisi yang tepat
        data[j + 1] = key
        print(f"  {key} ditempatkan pada posisi {j+1}")
        print("  Data saat ini:", data)

    print("\nData setelah diurutkan:", data)


# Contoh penggunaan
angka = [12, 11, 13, 5, 6]

insertion_sort(angka)


print("\n=== SETELAH DI MODIFIKASI ===\n")


def insertion_sort(data):
    print("Data sebelum diurutkan:", data)
    print("-" * 40)

    # Mulai dari indeks 1 (elemen pertama dianggap sudah terurut)
    for i in range(1, len(data)):
        key = data[i]
        j = i - 1

        print(f"\nIterasi ke-{i}")
        print(f"  Key yang akan disisipkan: {key}")
        print(f"  Data awal iterasi: {data}")

        # Geser elemen yang lebih besar ke kanan
        while j >= 0 and data[j] > key:
            print(f"    - Bandingkan key ({key}) dengan {data[j]} → {data[j]} lebih besar, geser ke kanan")
            data[j + 1] = data[j]
            j -= 1
            print(f"    Data setelah pergeseran: {data}")

        # Tempatkan key pada posisi yang tepat
        data[j + 1] = key
        print(f"  Key {key} ditempatkan pada posisi {j+1}")
        print(f"  Data setelah penempatan: {data}")
        print("-" * 40)

    print("\nData setelah diurutkan:", data)


# Contoh penggunaan
angka = [12, 11, 13, 5, 6]

insertion_sort(angka)
