# ------------------------------------
# PERANCANGAN STRUKTUR SEDERHANA
# ------------------------------------

# Membuat struktur sederhana menggunakan class
class Buah:
    def __init__(self, nama, harga, stok):
        self.nama = nama
        self.harga = harga
        self.stok = stok

# Membuat objek dari struktur Buah
apel = Buah("Apel", 15000, 30)
jeruk = Buah("Jeruk", 12000, 25)

# Menampilkan data
print("=== DATA BUAH ===")
print("Nama :", apel.nama)
print("Harga:", apel.harga)
print("Stok :", apel.stok)

print("\nNama :", jeruk.nama)
print("Harga:", jeruk.harga)
print("Stok :", jeruk.stok)

# Mengubah nilai dalam struktur
apel.stok = 40
print("\nSetelah stok Apel diperbarui:")
print("Nama :", apel.nama)
print("Harga:", apel.harga)
print("Stok :", apel.stok)

print("\n=== SETELAH DI MODIFIKASI ===")

# ------------------------------------
# PERANCANGAN STRUKTUR SEDERHANA (MODIFIKASI)
# ------------------------------------

# Membuat struktur sederhana menggunakan class
class Buah:
    def __init__(self, nama, harga, stok):
        self.nama = nama
        self.harga = harga
        self.stok = stok

    # Method untuk mengubah harga dan stok
    def update_data(self, harga=None, stok=None):
        if harga is not None:
            self.harga = harga
        if stok is not None:
            self.stok = stok

    # Method untuk menampilkan data
    def tampil(self):
        print(f"Nama : {self.nama}")
        print(f"Harga: {self.harga}")
        print(f"Stok : {self.stok}\n")


# Membuat beberapa objek buah
apel = Buah("Apel", 15000, 30)
jeruk = Buah("Jeruk", 12000, 25)
mangga = Buah("Mangga", 18000, 40)

# Menyimpan semua buah dalam list
daftar_buah = [apel, jeruk, mangga]

print("\n=== DATA SEMUA BUAH ===")
for b in daftar_buah:
    b.tampil()

# Menambah buah baru
semangka = Buah("Semangka", 25000, 15)
daftar_buah.append(semangka)

print("=== SETELAH MENAMBAH BUAH BARU ===")
for b in daftar_buah:
    b.tampil()

# Mengubah data buah (contoh: stok apel bertambah)
apel.update_data(stok=50)

print("=== SETELAH DATA APEL DIUBAH ===")
apel.tampil()
