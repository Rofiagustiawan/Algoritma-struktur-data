# Variabel dinamis: bisa berubah tipe sesuai kebutuhan

buah = "Apel"   # tahap 1: nama buah (string)
print("Isi:", buah, "| Tipe:", type(buah))

buah = 15000    # tahap 2: harga buah (integer)
print("Isi:", buah, "| Tipe:", type(buah))

buah = 12.5     # tahap 3: berat buah (float)
print("Isi:", buah, "| Tipe:", type(buah))

buah = ["Apel", "Jeruk", "Mangga"]   # tahap 4: daftar buah (list)
print("Isi:", buah, "| Tipe:", type(buah))

buah = {"nama": "Pisang", "stok": 40}   # tahap 5: data buah (dictionary)
print("Isi:", buah, "| Tipe:", type(buah))

print("\n=== SETELAH DI MODIFIKASI ===")

# Variabel dinamis dengan konsep buah (versi modifikasi)

# Tahap 1: Nama buah (string)
buah = "Apel"
print("\n=== TAHAP 1: NAMA BUAH ===")
print("Isi :", buah)
print("Tipe:", type(buah))

# Tahap 2: Harga buah (integer)
buah = 15000
print("\n=== TAHAP 2: HARGA BUAH ===")
print("Isi :", buah)
print("Tipe:", type(buah))

# Tahap 3: Berat buah (float)
buah = 12.5
print("\n=== TAHAP 3: BERAT BUAH ===")
print("Isi :", buah)
print("Tipe:", type(buah))

# Tahap 4: Daftar buah (list)
buah = ["Apel", "Jeruk", "Mangga"]
print("\n=== TAHAP 4: DAFTAR BUAH ===")
print("Isi :", buah)
print("Tipe:", type(buah))

# Tahap 5: Data buah lengkap (dictionary)
buah = {"nama": "Pisang", "stok": 40}
print("\n=== TAHAP 5: DATA BUAH ===")
print("Isi :", buah)
print("Tipe:", type(buah))

# Tahap 6: Input pengguna (dinamis)
print("\n=== TAHAP 6: INPUT DINAMIS ===")
buah = input("Masukkan nama buah: ")  # otomatis string
print("Isi :", buah)
print("Tipe:", type(buah))

# Tahap 7: Ubah menjadi stok (integer)
buah = int(input("Masukkan stok buah: "))
print("\nIsi :", buah)
print("Tipe:", type(buah))
