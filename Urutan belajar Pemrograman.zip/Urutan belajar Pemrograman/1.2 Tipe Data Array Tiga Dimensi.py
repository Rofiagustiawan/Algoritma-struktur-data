# Array 3 Dimensi: [Gudang][Daftar Buah][Detail Buah]
# Format Detail: [Nama Buah, Harga, Stok]

buah = [
    [   # Gudang 1
        ["Apel", 15000, 30],
        ["Mangga", 20000, 25],
        ["Jeruk", 18000, 40]
    ],
    [   # Gudang 2
        ["Pisang", 12000, 50],
        ["Semangka", 25000, 15],
        ["Anggur", 30000, 20]
    ]
]

print("=== DATA BUAH 3 DIMENSI (GUDANG) ===\n")

for g, gudang in enumerate(buah, start=1):
    print(f"--- GUDANG {g} ---")
    for item in gudang:
        print(f"Buah: {item[0]} | Harga: {item[1]} | Stok: {item[2]}")
    print()  # baris kosong tiap gudang

print("\n=== SETELAH DI MODIFIKASI ===")

# Array 3 Dimensi: [Gudang][Daftar Buah][Detail Buah]
# Format Detail: [Nama Buah, Harga, Stok]

buah = [
    [   # Gudang 1
        ["Apel", 15000, 30],
        ["Mangga", 20000, 25],
        ["Jeruk", 18000, 40]
    ],
    [   # Gudang 2
        ["Pisang", 12000, 50],
        ["Semangka", 25000, 15],
        ["Anggur", 30000, 20]
    ]
]

print("\n=== DATA BUAH 3 DIMENSI (GUDANG) ===\n")

# 1. Menampilkan data buah per gudang
total_stok = 0

for g, gudang in enumerate(buah, start=1):
    print(f"--- GUDANG {g} ---")
    for item in gudang:
        print(f"Buah: {item[0]} | Harga: {item[1]} | Stok: {item[2]}")
        total_stok += item[2]
    print(f"Total jenis buah di Gudang {g}: {len(gudang)}\n")

# 2. Menampilkan total stok seluruh gudang
print(f"TOTAL STOK SELURUH GUDANG: {total_stok}\n")

# 3. Menampilkan buah dengan harga tertinggi per gudang
print("=== Buah dengan Harga Tertinggi per Gudang ===")
for g, gudang in enumerate(buah, start=1):
    tertinggi = max(gudang, key=lambda x: x[1])
    print(f"Gudang {g}: {tertinggi[0]} (Rp {tertinggi[1]})")
print()

# 4. Menambahkan buah baru ke gudang tertentu
buah_baru = ["Pepaya", 16000, 18]
buah[0].append(buah_baru)  # Tambahkan ke Gudang 1

print("=== Setelah Menambah Buah Baru ke Gudang 1 ===")
for item in buah[0]:
    print(f"Buah: {item[0]} | Harga: {item[1]} | Stok: {item[2]}")
