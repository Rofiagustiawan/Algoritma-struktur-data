# Struktur sederhana data buah menggunakan dictionary

buah = {
    "nama": "Apel",
    "harga": 15000,
    "stok": 30
}

print("=== DATA BUAH ===")
print("Nama  :", buah["nama"])
print("Harga :", buah["harga"])
print("Stok  :", buah["stok"])

print("\n=== SETELAH DI MODIFIKASI ===")

# Struktur sederhana data buah menggunakan dictionary (versi modifikasi)

# Data awal
buah = {
    "nama": "Apel",
    "harga": 15000,
    "stok": 30
}

print("\n=== DATA BUAH AWAL ===")
print("Nama  :", buah["nama"])
print("Harga :", buah["harga"])
print("Stok  :", buah["stok"])

# Memodifikasi data buah
print("\n=== PERBARUI DATA BUAH ===")
buah["nama"] = input("Masukkan nama buah baru: ")
buah["harga"] = int(input("Masukkan harga baru: "))
buah["stok"] = int(input("Masukkan stok baru: "))

# Menampilkan data setelah diperbarui
print("\n=== DATA BUAH SETELAH DIPERBARUI ===")
for key, value in buah.items():
    print(f"{key.capitalize():<6}: {value}")

