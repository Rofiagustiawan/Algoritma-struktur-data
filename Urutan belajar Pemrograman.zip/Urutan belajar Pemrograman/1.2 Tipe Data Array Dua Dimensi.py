# Format: [Nama Buah, Harga, Stok]
buah = [
    ["Apel", 15000, 30],
    ["Mangga", 20000, 25],
    ["Jeruk", 18000, 40],
    ["Pisang", 12000, 50]
]

print("=== DATA BUAH (NAMA, HARGA, STOK) ===")
for item in buah:
    print(f"Buah: {item[0]}, Harga: {item[1]}, Stok: {item[2]}")

print("\n=== SETELAH DI MODIFIKASI ===")

# Format: [Nama Buah, Harga, Stok]
buah = [
    ["Apel", 15000, 30],
    ["Mangga", 20000, 25],
    ["Jeruk", 18000, 40],
    ["Pisang", 12000, 50]
]

print("\n=== DATA BUAH (NAMA, HARGA, STOK) ===")

total_stok = 0

for i, item in enumerate(buah, start=1):
    print(f"{i}. Buah: {item[0]} | Harga: {item[1]} | Stok: {item[2]}")
    total_stok += item[2]

# Mencari buah dengan harga tertinggi & terendah
buah_termahal = max(buah, key=lambda x: x[1])
buah_termurah = min(buah, key=lambda x: x[1])

print("\n=== INFORMASI TAMBAHAN ===")
print("Total seluruh stok buah:", total_stok)
print(f"Buah termahal  : {buah_termahal[0]} (Rp {buah_termahal[1]})")
print(f"Buah termurah  : {buah_termurah[0]} (Rp {buah_termurah[1]})")
