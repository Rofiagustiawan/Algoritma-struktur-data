# Menyimpan bilangan float
tinggi = 170.5
berat = 55.25


print("Tinggi badan:", tinggi)
print("Berat badan :", berat)

print("\n=== SETELAH DI MODIFIKASI ===")

# Menyimpan bilangan float
tinggi = 170.5   # dalam cm
berat = 55.25    # dalam kg


print("\nTinggi badan :", tinggi, "cm")
print("Berat badan  :", berat, "kg")

# Konversi tinggi ke meter untuk perhitungan BMI
tinggi_meter = tinggi / 100

# Hitung BMI
bmi = berat / (tinggi_meter ** 2)

print("\n--- HASIL PERHITUNGAN ---")
print("Tinggi dalam meter :", round(tinggi_meter, 2))
print("BMI (Indeks Massa Tubuh) :", round(bmi, 2))

# Kategori BMI sederhana
print("\n--- KATEGORI BMI ---")
if bmi < 18.5:
    print("Kategori: Kekurangan berat badan")
elif 18.5 <= bmi < 24.9:
    print("Kategori: Normal / Ideal")
elif 25 <= bmi < 29.9:
    print("Kategori: Kelebihan berat badan")
else:
    print("Kategori: Obesitas")
