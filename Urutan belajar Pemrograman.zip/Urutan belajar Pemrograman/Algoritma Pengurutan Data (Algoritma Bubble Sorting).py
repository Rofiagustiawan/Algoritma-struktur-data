# ----------------------------------
# BUBBLE SORT SEDERHANA
# ----------------------------------

def bubble_sort(data):
    n = len(data)
    print("Data sebelum diurutkan:", data)

    # proses bubble sort
    for i in range(n - 1):
        for j in range(n - i - 1):
            # Membandingkan elemen bersebelahan
            if data[j] > data[j + 1]:
                # Menukar posisi
                data[j], data[j + 1] = data[j + 1], data[j]
        
        print(f"Iterasi ke-{i+1} :", data)

    print("Data setelah diurutkan :", data)


# Contoh penggunaan
angka = [5, 3, 8, 1, 2]

bubble_sort(angka)

print("\n=== SETELAH DI MODIFIKASI ===\n")

import tkinter as tk
from tkinter import scrolledtext

# -------------------------------------
# BUBBLE SORT AUTOMATIS + PROSES TUKAR
# -------------------------------------

def start_sorting(event=None):  # event=None agar ENTER bisa dipakai
    global i, j, data, n
    i = 0
    j = 0

    output.delete(1.0, tk.END)  # bersihkan output setiap mulai sorting

    raw = entry.get().replace(" ", "")   # hilangkan seluruh spasi

    # Validasi input
    if not raw.isdigit():
        output.insert(tk.END, "Input hanya boleh angka!\n")
        return

    # Konversi setiap digit menjadi elemen array
    data = [int(x) for x in raw]

    n = len(data)
    output.insert(tk.END, f"Data awal: {data}\n\n")

    bubble_step()


def bubble_step():
    global i, j, data, n

    if i < n - 1:
        if j < n - i - 1:

            output.insert(tk.END, f"Membandingkan {data[j]} dan {data[j+1]}\n")

            before = data.copy()

            if data[j] > data[j + 1]:
                data[j], data[j + 1] = data[j + 1], data[j]
                output.insert(tk.END, "   -> Terjadi pertukaran!\n")
                output.insert(tk.END, f"      Sebelum: {before}\n")
                output.insert(tk.END, f"      Sesudah: {data}\n\n")
            else:
                output.insert(tk.END, "   -> Tidak ditukar\n\n")

            j += 1
            root.after(600, bubble_step)

        else:
            output.insert(tk.END, f"--- Iterasi ke-{i+1} selesai: {data}\n\n")
            j = 0
            i += 1
            root.after(600, bubble_step)

    else:
        output.insert(tk.END, f"Data akhir (sudah diurutkan): {data}\n\n")
        output.insert(tk.END, "-"*40 + "\n\n")


# ------------------------
# TOMBOL REFRESH
# ------------------------

def refresh():
    entry.delete(0, tk.END)
    output.delete(1.0, tk.END)


# ------------------------
# GUI TKINTER
# ------------------------

root = tk.Tk()
root.title("Bubble Sort Otomatis + Enter + Refresh")
root.geometry("650x450")

label = tk.Label(root, text="Masukkan angka (tanpa spasi pun bisa):")
label.pack()

entry = tk.Entry(root, width=60)
entry.pack()

# Menjalankan program saat tekan ENTER
entry.bind("<Return>", start_sorting)

# Tombol mulai
btn = tk.Button(root, text="Mulai Sorting", command=start_sorting)
btn.pack()

# Tombol refresh
btn_refresh = tk.Button(root, text="Refresh", command=refresh)
btn_refresh.pack()

# Output
output = scrolledtext.ScrolledText(root, width=80, height=20)
output.pack()

root.mainloop()
