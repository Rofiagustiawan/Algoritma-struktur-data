buah = ["Apel", "Mangga", "Jeruk", "Pisang"]

print("Menampilkan buah satu per satu:")
for item in buah:
    print("-", item)

print("\n=== SETELAH DI MODIFIKASI ===")

buah = ["Apel", "Mangga", "Jeruk", "Pisang"]


print("\nTotal buah:", len(buah))

print("\nMenampilkan buah satu per satu:")
for i, item in enumerate(buah, start=1):
    print(f"{i}. {item} (Huruf pertama: {item[0]})")

# Menampilkan buah yang paling panjang namanya
terpanjang = max(buah, key=len)
print("\nBuah dengan nama terpanjang :", terpanjang)
print("Jumlah huruf                 :", len(terpanjang))
