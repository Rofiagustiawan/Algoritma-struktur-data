# ----------------------------------
# LINEAR SEARCH SEDERHANA
# ----------------------------------

def linear_search(data, target):
    print("Mencari:", target)
    for i in range(len(data)):
        if data[i] == target:
            return i  # ditemukan
    return -1  # tidak ditemukan


# Contoh pemakaian
buah = ["Apel", "Jeruk", "Mangga", "Pisang", "Semangka"]

hasil = linear_search(buah, "Mangga")

if hasil != -1:
    print("Data ditemukan pada indeks:", hasil)
else:
    print("Data tidak ditemukan")

print("\n=== SETELAH DI MODIFIKASI ===\n")

# --------------
# LINEAR SEARCH 
# --------------

def linear_search(data, target):
    print(f"\n=== PROSES MENCARI '{target}' ===")
    
    for i in range(len(data)):
        print(f"Memeriksa indeks {i} → {data[i]}")
        
        if data[i] == target:
            print(f"✓ Data '{target}' ditemukan pada indeks {i}")
            return i  # ditemukan

    print(f"✗ Data '{target}' tidak ditemukan dalam daftar.")
    return -1  # tidak ditemukan


# Contoh pemakaian
buah = ["Apel", "Jeruk", "Mangga", "Pisang", "Semangka"]

print("Daftar Buah:", buah)

hasil = linear_search(buah, "Mangga")

print("\nHasil pencarian:")
if hasil != -1:
    print("Data ditemukan di indeks:", hasil)
else:
    print("Data tidak ditemukan")
